bl_info = {
    "name": "Align & Distribute Tool",
    "author": "Holymeo & AI",
    "version": (4, 2, 2),
    "blender": (4, 1, 0),
    "location": "3D Viewport > Editor Type Menu > Align & Distribute Tool (only visible in Object Mode)",
    "description": "Align, Distribute, Distribute Spacing Objects",
    "category": "Object",
}

import bpy
import os
import tempfile
import bpy.utils.previews
from mathutils import Vector
custom_icons = None
temp_icon_paths = []
def color_to_hex(color):
    """Chuyển đổi màu RGBA của Blender thành mã màu HEX."""
    return "#{:02x}{:02x}{:02x}".format(int(color[0]*255), int(color[1]*255), int(color[2]*255))
def reload_icons(self=None, context=None):
    """Tải lại các icon với màu sắc được chọn từ Add-on Preferences."""
    global custom_icons, temp_icon_paths
    if custom_icons:
        bpy.utils.previews.remove(custom_icons)
    for path in temp_icon_paths:
        try: os.remove(path)
        except OSError: pass
    temp_icon_paths.clear()
    custom_icons = bpy.utils.previews.new()
    if context:
        addon_prefs = context.preferences.addons[__name__].preferences
        hex_color = color_to_hex(addon_prefs.icon_color)
        addon_dir = os.path.dirname(__file__)
        icons_dir = os.path.join(addon_dir, "UI")
        if os.path.exists(icons_dir):
            for f in os.listdir(icons_dir):
                if f.endswith(".svg"):
                    try:
                        with open(os.path.join(icons_dir, f), 'r', encoding='utf-8') as file:
                            svg_data = file.read()
                        modified_svg_data = svg_data.replace("currentColor", hex_color)
                        with tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.svg', encoding='utf-8') as temp_f:
                            temp_f.write(modified_svg_data)
                            temp_path = temp_f.name
                        name = os.path.splitext(f)[0]
                        custom_icons.load(name, temp_path, 'IMAGE')
                        temp_icon_paths.append(temp_path)
                    except Exception as e:
                        print(f"Error processing icon {f}: {e}")
        else:
            print(f"Icon directory not found at: {icons_dir}")
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
def unload_icons():
    """Gỡ bỏ icon và dọn dẹp file tạm."""
    global custom_icons, temp_icon_paths
    if custom_icons:
        bpy.utils.previews.remove(custom_icons)
        custom_icons = None
    for path in temp_icon_paths:
        try: os.remove(path)
        except OSError: pass
    temp_icon_paths.clear()
class AlignToolAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    icon_color: bpy.props.FloatVectorProperty(
        name="Icon Color",
        description="Color setting for SVG icons. Requires SVG files to use 'currentColor' for fill.",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0, 1.0),
        size=4,
        min=0.0,
        max=1.0,
        update=reload_icons
    )
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column()
        col.label(text="Setting Color Icon")
        row = col.row()
        row.prop(self, "icon_color")
def get_bounds(obj):
    if obj.type != 'MESH' or not obj.data.vertices:
        return {'min': obj.location, 'max': obj.location, 'center': obj.location}
    local_corners = [Vector(c) for c in obj.bound_box]
    world_corners = [obj.matrix_world @ c for c in local_corners]
    min_x = min(c.x for c in world_corners); max_x = max(c.x for c in world_corners)
    min_y = min(c.y for c in world_corners); max_y = max(c.y for c in world_corners)
    min_z = min(c.z for c in world_corners); max_z = max(c.z for c in world_corners)
    return {
        'min': Vector((min_x, min_y, min_z)),
        'max': Vector((max_x, max_y, max_z)),
        'center': Vector(((min_x + max_x) / 2, (min_y + max_y) / 2, (min_z + max_z) / 2))
    }
def get_target_value(objects, active_obj, target_method, bounds_method, axis_index, side):
    target_pool = [active_obj] if target_method == 'ACTIVE' and active_obj else objects
    if not target_pool: return None
    if bounds_method == 'BOUNDS':
        all_bounds = [get_bounds(o) for o in target_pool]
        if side == 'MIN': return min(b['min'][axis_index] for b in all_bounds)
        if side == 'MAX': return max(b['max'][axis_index] for b in all_bounds)
        overall_min = min(b['min'][axis_index] for b in all_bounds)
        overall_max = max(b['max'][axis_index] for b in all_bounds)
        return (overall_min + overall_max) / 2
    else: # ORIGIN
        locations = [o.location[axis_index] for o in target_pool]
        if side == 'MIN': return min(locations)
        if side == 'MAX': return max(locations)
        return sum(locations) / len(locations)
class AlignToolProperties(bpy.types.PropertyGroup):
    by: bpy.props.EnumProperty(
        name="By", description="Phương thức tính toán điểm tham chiếu",
        items=[('BOUNDS', "Mesh Bounds", "Align By Mesh Bounds", "MOD_WIREFRAME", 0), ('ORIGIN', "Origin Objects", "Align By Origin Objects", "CON_PIVOT", 1)],
        default='BOUNDS'
    )
    target: bpy.props.EnumProperty(
        name="To", description="Đối tượng tham chiếu để căn chỉnh",
        items=[('ACTIVE', "Active Element", "Align To Active Element", "PIVOT_ACTIVE", 0), ('SELECTION', "Selection Objects", "Align To Selection Objects", "SELECT_SET", 1)],
        default='ACTIVE'
    )
    spacing_value: bpy.props.FloatProperty(
        name="Spacing", description="To specify spacing value, Only works when 'Align to Active Element' is selected",
        default=0.1, subtype='DISTANCE', unit='LENGTH'
    )
class ALIGNTOOL_OT_set_enum_with_tooltip(bpy.types.Operator):
    bl_idname = "aligntool.set_enum_with_tooltip"; bl_label = "Set Enum Value"; bl_options = {'INTERNAL'}
    data_path: bpy.props.StringProperty(); value: bpy.props.StringProperty(); tooltip: bpy.props.StringProperty()
    @classmethod
    def description(cls, context, properties): return properties.tooltip
    def execute(self, context):
        path_parts = self.data_path.split('.'); prop_name = path_parts.pop(); base_obj = context
        try:
            for part in path_parts: base_obj = getattr(base_obj, part)
        except AttributeError: self.report({'ERROR'}, f"Could not resolve base path for '{self.data_path}'"); return {'CANCELLED'}
        setattr(base_obj, prop_name, self.value)
        return {'FINISHED'}
class ALIGN_OT_align(bpy.types.Operator):
    bl_idname = "object.custom_align"; bl_label = "Align Objects"; bl_options = {'REGISTER', 'UNDO'}
    axis: bpy.props.EnumProperty(items=[('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")])
    side: bpy.props.EnumProperty(items=[('MIN', "Min", ""), ('CENTER', "Center", ""), ('MAX', "Max", "")])
    @classmethod
    def description(cls, context, properties):
        side_map = { 'MIN': 'minimum edge', 'CENTER': 'center', 'MAX': 'maximum edge' }; side_name = side_map.get(properties.side, 'edge')
        return f"Align objects to the {side_name} on the {properties.axis} axis"
    def execute(self, context):
        props = context.scene.align_tool_props; selected_objs = [o for o in context.selected_objects if o.type == 'MESH']; active_obj = context.active_object
        if not selected_objs or (props.target == 'ACTIVE' and (not active_obj or active_obj not in selected_objs)): self.report({'WARNING'}, "Cần một đối tượng mesh active."); return {'CANCELLED'}
        axis_index = {'X': 0, 'Y': 1, 'Z': 2}[self.axis]; target_val = get_target_value(selected_objs, active_obj, props.target, props.by, axis_index, self.side)
        if target_val is None: return {'CANCELLED'}
        for obj in selected_objs:
            if props.target == 'ACTIVE' and obj == active_obj: continue
            if props.by == 'BOUNDS':
                bounds = get_bounds(obj)
                if self.side == 'MIN': offset = obj.location[axis_index] - bounds['min'][axis_index]
                elif self.side == 'MAX': offset = obj.location[axis_index] - bounds['max'][axis_index]
                else: offset = obj.location[axis_index] - bounds['center'][axis_index]
                obj.location[axis_index] = target_val + offset
            else: obj.location[axis_index] = target_val
        return {'FINISHED'}
class ALIGN_OT_distribute(bpy.types.Operator):
    bl_idname = "object.custom_distribute"; bl_label = "Distribute Objects"; bl_options = {'REGISTER', 'UNDO'}
    axis: bpy.props.EnumProperty(items=[('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")])
    side: bpy.props.EnumProperty(items=[('MIN', "Min", ""), ('CENTER', "Center", ""), ('MAX', "Max", "")])
    @classmethod
    def description(cls, context, properties):
        side_map = { 'MIN': 'minimum edges', 'CENTER': 'centers', 'MAX': 'maximum edges' }; side_name = side_map.get(properties.side, 'edges')
        return f"Distribute objects evenly by their {side_name} along the {properties.axis} axis"
    def execute(self, context):
        props = context.scene.align_tool_props; selected_objs = [o for o in context.selected_objects if o.type == 'MESH']
        if len(selected_objs) < 3: self.report({'WARNING'}, "Cần ít nhất 3 đối tượng mesh."); return {'CANCELLED'}
        axis_index = {'X': 0, 'Y': 1, 'Z': 2}[self.axis]; side_key = self.side.lower()
        if props.by == 'BOUNDS':
            sorted_objs = sorted(selected_objs, key=lambda o: get_bounds(o)['center'][axis_index])
            bounds_list = [get_bounds(o) for o in sorted_objs]
            start_pos = bounds_list[0][side_key][axis_index]
            end_pos = bounds_list[-1][side_key][axis_index]
        else: # ORIGIN
            sorted_objs = sorted(selected_objs, key=lambda o: o.location[axis_index])
            start_pos = sorted_objs[0].location[axis_index]
            end_pos = sorted_objs[-1].location[axis_index]
        step = (end_pos - start_pos) / (len(sorted_objs) - 1)
        for i, obj in enumerate(sorted_objs[1:-1], 1):
            target_pos = start_pos + i * step
            if props.by == 'BOUNDS':
                offset = obj.location[axis_index] - get_bounds(obj)[side_key][axis_index]
                obj.location[axis_index] = target_pos + offset
            else: # ORIGIN
                obj.location[axis_index] = target_pos
        return {'FINISHED'}
class ALIGN_OT_distribute_spacing(bpy.types.Operator):
    bl_idname = "object.custom_distribute_spacing"; bl_label = "Distribute with Spacing"; bl_options = {'REGISTER', 'UNDO'}
    axis: bpy.props.EnumProperty(items=[('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")])
    @classmethod
    def description(cls, context, properties): return f"Distribute objects with a defined spacing along the {properties.axis} axis, relative to the active object"
    def execute(self, context):
        props = context.scene.align_tool_props; active_obj = context.active_object; other_objs = [o for o in context.selected_objects if o != active_obj and o.type == 'MESH']
        if not other_objs: self.report({'INFO'}, "Không có đối tượng nào khác để phân bố."); return {'CANCELLED'}
        spacing = props.spacing_value; axis_index = {'X': 0, 'Y': 1, 'Z': 2}[self.axis]; active_bounds = get_bounds(active_obj); active_center = active_bounds['center'][axis_index]
        left_objs = [o for o in other_objs if get_bounds(o)['center'][axis_index] < active_center]; right_objs = [o for o in other_objs if get_bounds(o)['center'][axis_index] >= active_center]
        left_objs.sort(key=lambda o: get_bounds(o)['center'][axis_index], reverse=True); right_objs.sort(key=lambda o: get_bounds(o)['center'][axis_index])
        current_pos = active_bounds['max'][axis_index]
        for obj in right_objs:
            bounds = get_bounds(obj); offset = obj.location[axis_index] - bounds['min'][axis_index]
            obj.location[axis_index] = current_pos + spacing + offset; current_pos = bounds['max'][axis_index] - bounds['min'][axis_index] + current_pos + spacing
        current_pos = active_bounds['min'][axis_index]
        for obj in left_objs:
            bounds = get_bounds(obj); offset = obj.location[axis_index] - bounds['max'][axis_index]
            obj.location[axis_index] = current_pos - spacing + offset; current_pos = -(bounds['max'][axis_index] - bounds['min'][axis_index]) + current_pos - spacing
        return {'FINISHED'}
class ALIGNTOOL_MT_by_menu(bpy.types.Menu):
    bl_label = "Align By"; bl_idname = "ALIGNTOOL_MT_by_menu"
    def draw(self, context):
        layout = self.layout; props = context.scene.align_tool_props; prop_rna = props.bl_rna.properties["by"]
        for item in prop_rna.enum_items:
            op = layout.operator(ALIGNTOOL_OT_set_enum_with_tooltip.bl_idname, text=item.name, icon=item.icon)
            op.data_path = "scene.align_tool_props.by"; op.value = item.identifier; op.tooltip = item.description
class ALIGNTOOL_MT_to_menu(bpy.types.Menu):
    bl_label = "Align To"; bl_idname = "ALIGNTOOL_MT_to_menu"
    def draw(self, context):
        layout = self.layout; props = context.scene.align_tool_props; prop_rna = props.bl_rna.properties["target"]
        for item in prop_rna.enum_items:
            op = layout.operator(ALIGNTOOL_OT_set_enum_with_tooltip.bl_idname, text=item.name, icon=item.icon)
            op.data_path = "scene.align_tool_props.target"; op.value = item.identifier; op.tooltip = item.description
class ALIGNTOOL_PT_PopoverPanel(bpy.types.Panel):
    bl_label = "Align & Distribute Tool"; bl_idname = "OBJECT_PT_align_tool_popover"
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = "Tool"
    bl_ui_units_x = 5
    def draw(self, context):
        layout = self.layout
        props = context.scene.align_tool_props
        icons = custom_icons
        layout.label(text="Align Objects")
        col = layout.column(align=True)
        row = col.row(align=True); split = row.split(factor=0.15, align=True); split.label(text="X")
        button_row = split.row(align=True)
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Align_Left"].icon_id); op.axis, op.side = 'X', 'MIN'
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Center_Alignment_Horizontal"].icon_id); op.axis, op.side = 'X', 'CENTER'
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Align_Right"].icon_id); op.axis, op.side = 'X', 'MAX'
        row = col.row(align=True); split = row.split(factor=0.15, align=True); split.label(text="Y")
        button_row = split.row(align=True)
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Align_Left"].icon_id); op.axis, op.side = 'Y', 'MIN'
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Center_Alignment_Horizontal"].icon_id); op.axis, op.side = 'Y', 'CENTER'
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Align_Right"].icon_id); op.axis, op.side = 'Y', 'MAX'
        row = col.row(align=True); split = row.split(factor=0.15, align=True); split.label(text="Z")
        button_row = split.row(align=True)
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Align_Top"].icon_id); op.axis, op.side = 'Z', 'MAX'
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Center_Alignment_Vertical"].icon_id); op.axis, op.side = 'Z', 'CENTER'
        op = button_row.operator(ALIGN_OT_align.bl_idname, text="", icon_value=icons["Align_Bottom"].icon_id); op.axis, op.side = 'Z', 'MIN'
        layout.separator()
        dist_col = layout.column(); dist_col.enabled = (props.target == 'SELECTION')
        dist_col.label(text="Distribute Objects")
        col = dist_col.column(align=True)
        row = col.row(align=True); split = row.split(factor=0.15, align=True); split.label(text="X")
        button_row = split.row(align=True)
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Horizontal_Left"].icon_id); op.axis, op.side = 'X', 'MIN'
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Horizontal_Center"].icon_id); op.axis, op.side = 'X', 'CENTER'
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Horizontal_Right"].icon_id); op.axis, op.side = 'X', 'MAX'
        row = col.row(align=True); split = row.split(factor=0.15, align=True); split.label(text="Y")
        button_row = split.row(align=True)
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Horizontal_Left"].icon_id); op.axis, op.side = 'Y', 'MIN'
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Horizontal_Center"].icon_id); op.axis, op.side = 'Y', 'CENTER'
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Horizontal_Right"].icon_id); op.axis, op.side = 'Y', 'MAX'
        row = col.row(align=True); split = row.split(factor=0.15, align=True); split.label(text="Z")
        button_row = split.row(align=True)
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Vertical_Top"].icon_id); op.axis, op.side = 'Z', 'MAX'
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Vertical_Center"].icon_id); op.axis, op.side = 'Z', 'CENTER'
        op = button_row.operator(ALIGN_OT_distribute.bl_idname, text="", icon_value=icons["Distribute_Vertical_Bottom"].icon_id); op.axis, op.side = 'Z', 'MIN'
        layout.separator()
        spacing_col = layout.column(); spacing_col.enabled = (props.target == 'ACTIVE')
        spacing_col.label(text="Distribute Spacing")
        spacing_col.prop(props, "spacing_value", text="")
        row = spacing_col.row(align=True)
        op = row.operator(ALIGN_OT_distribute_spacing.bl_idname, text="X", icon_value=icons["Distribute_Space_Horizontal"].icon_id); op.axis = 'X'
        op = row.operator(ALIGN_OT_distribute_spacing.bl_idname, text="Y", icon_value=icons["Distribute_Space_Horizontal"].icon_id); op.axis = 'Y'
        op = row.operator(ALIGN_OT_distribute_spacing.bl_idname, text="Z", icon_value=icons["Distribute_Space_Vertical"].icon_id); op.axis = 'Z'
        layout.separator()
        layout.label(text="Align")
        row = layout.row(align=True)
        by_icons = {item.identifier: item.icon for item in props.bl_rna.properties['by'].enum_items}
        target_icons = {item.identifier: item.icon for item in props.bl_rna.properties['target'].enum_items}
        box_by = row.box(); row_by = box_by.row(align=True); row_by.label(text="By:"); row_by.menu(ALIGNTOOL_MT_by_menu.bl_idname, text="", icon=by_icons.get(props.by, 'NONE'))
        box_to = row.box(); row_to = box_to.row(align=True); row_to.label(text="To:"); row_to.menu(ALIGNTOOL_MT_to_menu.bl_idname, text="", icon=target_icons.get(props.target, 'NONE'))
def draw_align_tool_menu_item(self, context):
    if context.mode == 'OBJECT' and custom_icons and "Align_Left" in custom_icons:
        self.layout.popover(
            panel=ALIGNTOOL_PT_PopoverPanel.bl_idname,
            text="",
            icon_value=custom_icons["Align_Left"].icon_id
        )
classes = (
    AlignToolAddonPreferences,
    AlignToolProperties,
    ALIGNTOOL_OT_set_enum_with_tooltip,
    ALIGN_OT_align,
    ALIGN_OT_distribute,
    ALIGN_OT_distribute_spacing,
    ALIGNTOOL_MT_by_menu,
    ALIGNTOOL_MT_to_menu,
    ALIGNTOOL_PT_PopoverPanel,
)
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.align_tool_props = bpy.props.PointerProperty(type=AlignToolProperties)
    if bpy.context:
        reload_icons(context=bpy.context)
    bpy.types.VIEW3D_MT_editor_menus.append(draw_align_tool_menu_item)
def unregister():
    unload_icons()
    bpy.types.VIEW3D_MT_editor_menus.remove(draw_align_tool_menu_item)
    del bpy.types.Scene.align_tool_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
if __name__ == "__main__":
    register()

